package com.example.lab1

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    private lateinit var okButton: Button
    private lateinit var cancelButton: Button
    private lateinit var textView: TextView
    private lateinit var rdGroup: RadioGroup
    private lateinit var editText: EditText
    private lateinit var rdButton1: RadioButton
    private lateinit var rdButton2: RadioButton
    private lateinit var rdButton3: RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rdGroup = findViewById(R.id.radio_group)
        textView = findViewById(R.id.text_view)
        cancelButton = findViewById(R.id.cancel_button)
        okButton = findViewById(R.id.ok_button)
        editText = findViewById(R.id.et_input)
        rdButton1 = findViewById(R.id.rb_red)
        rdButton2 = findViewById(R.id.rb_green)
        rdButton3 = findViewById(R.id.rb_blue)
        okButton.setOnClickListener {
            val id = rdGroup.checkedRadioButtonId
            when(id) {
                -1 -> {
                    textView.text = editText.text
                }
                rdButton1.id -> {
                    textView.setTextColor(resources.getColor(R.color.red))
                    textView.text = editText.text
                }
                rdButton2.id -> {
                    textView.setTextColor(resources.getColor(R.color.green))
                    textView.text = editText.text
                }
                rdButton3.id -> {
                    textView.setTextColor(resources.getColor(R.color.blue))
                    textView.text = editText.text
                }
            }
        }
        cancelButton.setOnClickListener{
            textView.text = ""
        }
    }
}