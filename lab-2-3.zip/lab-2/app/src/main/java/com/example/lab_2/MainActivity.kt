package com.example.lab_2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var okButton: Button
    private lateinit var rdGroup: RadioGroup
    private lateinit var editText: EditText
    private lateinit var rdButton1: RadioButton
    private lateinit var rdButton2: RadioButton
    private lateinit var rdButton3: RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val fragment1 = InputFragment.newInstance()
        val fragment2 = OutputFragment.newInstance("", 0)
        supportFragmentManager.beginTransaction().apply {
            add(R.id.fragment2, fragment1)
            add(R.id.fragment, fragment2)
            commit()
        }
    }
}