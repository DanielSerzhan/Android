package com.example.lab_2

import android.content.Context
import android.content.Context.MODE_APPEND
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.fragment.app.Fragment
import java.io.File
import java.io.FileOutputStream
import android.widget.Toast

import android.content.Context.MODE_PRIVATE
import android.util.Log

import android.widget.EditText
import java.io.FileInputStream
import java.io.IOException


class InputFragment : Fragment(R.layout.fragment_input) {

    private lateinit var okButton: Button
    private lateinit var open: Button
    private lateinit var rdGroup: RadioGroup
    private lateinit var editText: EditText
    private lateinit var rdButton1: RadioButton
    private lateinit var rdButton2: RadioButton
    private lateinit var rdButton3: RadioButton
    private val FILE_NAME = "content.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rdGroup = view.findViewById(R.id.radio_group)
        okButton = view.findViewById(R.id.ok_button)
        editText = view.findViewById(R.id.et_input)
        rdButton1 = view.findViewById(R.id.rb_red)
        rdButton2 = view.findViewById(R.id.rb_green)
        rdButton3 = view.findViewById(R.id.rb_blue)
        open = view.findViewById(R.id.open)
        okButton.setOnClickListener {
            if (editText.text.isEmpty()) {
                Toast.makeText(activity, "Введіть текст", Toast.LENGTH_SHORT).show()
            } else {
                val id = rdGroup.checkedRadioButtonId
                when (id) {
                    rdButton1.id -> {
                        supportTransaction(
                            editText.text.toString(),
                            resources.getColor(R.color.red)
                        )
                    }
                    rdButton2.id -> {
                        supportTransaction(
                            editText.text.toString(),
                            resources.getColor(R.color.green)
                        )
                    }
                    rdButton3.id -> {
                        supportTransaction(
                            editText.text.toString(),
                            resources.getColor(R.color.blue)
                        )
                    }
                }
                var fos: FileOutputStream? = null
                try {
                    val text = editText.text.toString()
                    fos = requireContext().openFileOutput(FILE_NAME, MODE_APPEND)
                    fos!!.write(text.toByteArray())
                    fos.write("\n".toByteArray())
                    Toast.makeText(activity, "Запис збережено", Toast.LENGTH_SHORT).show()
                } catch (ex: IOException) {
                    ex.printStackTrace()
                }
            }
        }
        open.setOnClickListener {
            var fin: FileInputStream? = null
            try {
                fin = requireContext().openFileInput(FILE_NAME)
                val bytes = ByteArray(fin!!.available())
                fin.read(bytes)
                val intent = Intent(requireContext(), SecondActivity::class.java)
                startActivity(intent)
            } catch (ex: IOException) {
                Toast.makeText(activity, "Сховище пусте", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun supportTransaction(text: String, color: Int) {
        val fragment = OutputFragment.newInstance(text, color)
        parentFragmentManager.beginTransaction().apply {
            replace(R.id.fragment, fragment)
            commit()
        }
    }

    companion object {
        fun newInstance() = InputFragment()
    }
}

