package com.example.lab_2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment


private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
lateinit var cancelButton: Button

class OutputFragment : Fragment(R.layout.fragment_output) {
    private var param1: String? = null
    private var param2: Int? = null
    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getInt(ARG_PARAM2)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textView = view.findViewById(R.id.text_view)
        cancelButton = view.findViewById(R.id.cancel_button)
        textView.setTextColor(param2!!)
        textView.text = param1

        cancelButton.setOnClickListener {
            textView.text = ""
        }
    }

    companion object {
        fun newInstance(param1: String, param2: Int) =
            OutputFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putInt(ARG_PARAM2, param2)
                }
            }
    }
}