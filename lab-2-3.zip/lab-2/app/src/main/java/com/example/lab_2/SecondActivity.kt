package com.example.lab_2

import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.w3c.dom.Text
import java.io.File
import java.io.FileInputStream
import java.lang.StringBuilder
import android.widget.Toast

import java.io.IOException


class SecondActivity: AppCompatActivity() {
    private val FILE_NAME = "content.txt"
    lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)
        var fin: FileInputStream? = null
        textView = findViewById(R.id.result)
        try {
            fin = openFileInput(FILE_NAME)
            val bytes = ByteArray(fin.available())
            fin.read(bytes)
            val text = String(bytes)
            textView.text = text
        } catch (ex: IOException) {
            ex.printStackTrace()
        }
    }
}
